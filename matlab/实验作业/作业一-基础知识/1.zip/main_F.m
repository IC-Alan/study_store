function result = main_F(m,n)
A = zeros(m, n);
for i = 1:m
    for j = 1:n
        A(i,j) = randi(100);
    end
end

B = transpose(A,m,n);
x = find_min(A,m,n);
y = find_max(A,m,n);
C = find_sort(A,m,n);
disp('原矩阵A:');
disp(A);
disp('转置矩阵B:');
disp(B);
disp('最小值:');
disp(x);
disp('最大值:');
disp(y);
disp('排序后:');
disp(C);
end

function B = transpose(A,m,n)
B = zeros(n, m);
for i = 1:n
    for j = 1:m
        B(i,j) = A(j,i);
    end
end
end

function x = find_min(A,m,n)
x = A(1,1);
for i = 1:m
    for j = 1:n
        if x > A(i,j)
        x = A(i,j);
        end
    end
end
end

function y = find_max(A,m,n)
y = A(1,1);
for i = 1:m
    for j = 1:n
        if y < A(i,j)
        y = A(i,j);
        end
    end
end
end


function C = find_sort(A,m,n)
C = reshape(A, 1, []);
for i = 1:m*n
    for j = 1:m*n-1
        if C(j) > C(j+1)
            temp = C(j+1);
            C(j+1) = C(j);
            C(j) = temp;        
        end
    end
end
end