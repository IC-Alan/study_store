%% 用户输入文件路径和缩放比例
file_path = input('请输入图像文件路径（含扩展名,不加引号）: ', 's');  % 's' 表示字符串输入
scale = input('请输入缩放比例: ');

%% 读取图像
I = imread(file_path);

%% 调用自定义resize函数
R = resize(I, scale);
imwrite(R,"result.jpg");


figure('Name','缩放图','NumberTitle','off','WindowStyle','normal');
imshow(R,'InitialMagnification',100);
axis image;
truesize; 
figure('Name','原图','NumberTitle','off','WindowStyle','normal'); 
imshow(I,'InitialMagnification',100);
axis image;
truesize; 

function R = resize(I,x)
[rows,cols,ch] = size(I);
new_rows = round(rows * x);
new_cols = round(cols * x);
R = zeros(new_rows, new_cols, ch, 'like', I); % 保持和 I 一样的数据类型

for i = 1:new_rows
    for j = 1:new_cols
    % 映射到原图坐标
    src_x = min(max(i / x,1),rows);
    src_y = min(max(j / x,1),cols);
    x0 = floor(src_x); x1 = ceil(src_x);
    y0 = floor(src_y); y1 = ceil(src_y);
    u = src_x-x0;
    v = src_y-y0;
    R(i,j,:) = (1-u)*(1-v)*I(x0,y0,:)+(1-u)*v*I(x0,y1,:)+u*(1-v)*I(x1,y0,:)+u*v*I(x1,y1,:);
    end
end
end