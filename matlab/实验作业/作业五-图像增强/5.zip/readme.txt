运行方法

在命令行下输入main

输入要读取的文件路径（如./origin.jpg）