Path = input('请输入图像路径: ', 's');
Img = imread(Path);

kernel = [1 1 1;1 -8 1;1 1 1];
g = laplacian_enhance(Img,kernel);
imwrite(g, 'enhanced_image.png');  
% 显示两张图
subplot(1,2,1); imshow(Img); title('原始图像');
subplot(1,2,2); imshow(g);   title('拉普拉斯增强图');

function g = laplacian_enhance(I,kernel)
I = double(I);

[m,n,channels] = size(I);
I_pad = padarray(I, [1 1], 0, 'both');
g = zeros(m,n,channels);

for c = 1: channels
    for i = 1:m
            for j = 1:n
                region = I_pad(i:i+2, j:j+2,c);   % 当前邻域
                g(i,j,c) = I(i,j,c) - sum(sum(region .* kernel)); % 对应元素乘积和
            end
    end
end


% 限制在 0-255 范围并转 uint8
g(g < 0) = 0;
g(g > 255) = 255;
g = uint8(g);
end


