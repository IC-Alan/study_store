%% ------------------- 主程序 -------------------
folderPath = input('请输入待检索图像文件夹路径:（不带引号） ', 's');
refPath = input('请输入参考图像路径:（不带引号） ', 's');
topK = input('请输入希望检索出的图像个数: ');

% 获取所有子文件夹内的 .gif 图像（递归）
imgFiles = dir(fullfile(folderPath, '**', '*.gif'));
N = length(imgFiles);
if N == 0
    error('文件夹及子文件夹中没有找到图像！');
end


% 提取参考图像特征
refImg = imread(refPath);
refFeature = extractFeatureVector(refImg,refImg);

% 提取所有图像特征
features = zeros(length(refFeature), N);
for i = 1:N
    imgPath = fullfile(imgFiles(i).folder, imgFiles(i).name); % 拼完整路径
    img = imread(imgPath);
   
    features(:, i) = extractFeatureVector(img, refImg);
    fprintf("正在处理第 %d/%d 张图：%s\n", i, N, imgFiles(i).name);
end

% 计算余弦相似度
cosSims = features' * refFeature;
[sortedSims, idx] = sort(cosSims, 'descend');

% 输出前20个结果
topK = min(topK, N);
sortedIdx = idx(1:topK);

figure('Name', sprintf('最相似的前 %d 张图片', topK));
cols = 5;                        
rows = ceil(topK / cols); 
for i = 1:topK
    imgPath = fullfile(imgFiles(sortedIdx(i)).folder, imgFiles(sortedIdx(i)).name);
    img = imread(imgPath);
    if ndims(img) == 3
    img = rgb2gray(img);
    end
    BW = imbinarize(img);
    BW = bwareaopen(BW, 30);
    subplot(rows, cols, i);
    imshow(BW);
    title(sprintf('%d: %.4f', i, cosSims(sortedIdx(i))));
end

%% ------------------- 提取特征 -------------------
function feature = extractFeatureVector(I, refImg)
    validFeatures = {};

    % -------- 转灰度并预处理 --------
    if ndims(I) == 3
        I = rgb2gray(I);
    end
    I = imresize(I, [370 370]);
    BW = imbinarize(I);
    BW = bwareaopen(BW, 30);
    BW = ~BW;

    % -------- HOG 特征 --------
    cellSize = [8 8];
    hog = extractHOGFeatures(BW, 'CellSize', cellSize);
    hog = hog(:);
    if norm(hog) > 0 && all(~isnan(hog))
        hog = hog / (norm(hog) + eps);
        validFeatures{end+1} = hog;
    else
        warning('⚠️ 跳过 HOG 特征 (全零或 NaN)');
    end

    % -------- 参考图像处理 --------
    refBW = imbinarize(refImg);
    refBW = bwareaopen(refBW, 30);
    refBW = ~refBW;

    % -------- 区域特征 --------
    regionFeat = RegionFeature(BW, refBW, 2, 2);
    if norm(regionFeat) > 0 && all(~isnan(regionFeat))
        validFeatures{end+1} = regionFeat;
    else
        warning('⚠️ 跳过 RegionFeature (全零或 NaN)');
    end

    % -------- 方向特征 --------
    dirFeat = MorphoFeature(BW);
    if norm(dirFeat) > 0 && all(~isnan(dirFeat))
        validFeatures{end+1} = dirFeat;
    else
        warning('⚠️ 跳过 MorphoFeature (全零或 NaN)');
    end

    % -------- 边缘特征 --------
    edgeFeat = ContourFeature(BW);
    if norm(edgeFeat) > 0 && all(~isnan(edgeFeat))
        validFeatures{end+1} = edgeFeat;
    else
        warning('⚠️ 跳过 ContourFeature (全零或 NaN)');
    end

    % -------- 拼接所有有效特征 --------
    if isempty(validFeatures)
        warning('⚠️ 所有特征都无效！返回全零向量');
        feature = zeros(16,1); % 给个固定长度，防止报错
    else
        feature = vertcat(validFeatures{:});
        feature = feature / (norm(feature) + eps);
    end
end


%% ------------------- 局部特征 -------------------
function regionFeature = RegionFeature(BW, refBW, nRow, nCol)
if nargin < 3, nRow = 2; end
if nargin < 4, nCol = 2; end

% 裁剪最大连通区域
stats = regionprops(BW, 'BoundingBox');
if isempty(stats)
    regionFeature = zeros(nRow*nCol*6,1); % 每格6维
    return;
end
[~, idx] = max(arrayfun(@(s)s.BoundingBox(3)*s.BoundingBox(4), stats));
bbox = stats(idx).BoundingBox;
x1 = max(floor(bbox(1)),1); y1 = max(floor(bbox(2)),1);
x2 = min(ceil(x1+bbox(3)-1), size(BW,2));
y2 = min(ceil(y1+bbox(4)-1), size(BW,1));
subBW = BW(y1:y2, x1:x2);

% 对参考图像同样裁剪
refStats = regionprops(refBW, 'BoundingBox');
if isempty(refStats)
    refSubBW = refBW;
else
    [~, idxRef] = max(arrayfun(@(s)s.BoundingBox(3)*s.BoundingBox(4), refStats));
    bboxRef = refStats(idxRef).BoundingBox;
    x1r = max(floor(bboxRef(1)),1); y1r = max(floor(bboxRef(2)),1);
    x2r = min(ceil(x1r+bboxRef(3)-1), size(refBW,2));
    y2r = min(ceil(y1r+bboxRef(4)-1), size(refBW,1));
    refSubBW = refBW(y1r:y2r, x1r:x2r);
end
[hRef, wRef] = size(refSubBW);
subBW = imresize(subBW, [hRef, wRef]);
% 网格划分
[h,w] = size(subBW); [hRef, wRef] = size(refSubBW);
rows = floor(linspace(1,h+1,nRow+1)); cols = floor(linspace(1,w+1,nCol+1));
rowsRef = floor(linspace(1,hRef+1,nRow+1)); colsRef = floor(linspace(1,wRef+1,nCol+1));

regionFeature = [];

for i = 1:nRow
    for j = 1:nCol
        cellBW = subBW(rows(i):rows(i+1)-1, cols(j):cols(j+1)-1);
        refCellBW = refSubBW(rowsRef(i):rowsRef(i+1)-1, colsRef(j):colsRef(j+1)-1);

        % 笔画占比
        strokeRatio = sum(cellBW(:)) / numel(cellBW);

        % 方向性
        dirFeature = MorphoFeature(cellBW);

        % 重叠率
        overlapRatio = sum(cellBW(:) & refCellBW(:)) / max(numel(cellBW),1);

        % 拼接每格特征
        regionFeature = [regionFeature; strokeRatio;dirFeature;overlapRatio];
    end
end

% 归一化
regionFeature = regionFeature / (norm(regionFeature)+eps);

end

%% ------------------- 方向性形态学特征 -------------------
function feature = MorphoFeature(I)
angles = [0 45 90 135];
len = 15;
dir_counts = zeros(size(angles));

for k = 1:length(angles)
    SE = strel('line', len, angles(k));
    eroded = imerode(I, SE);
    matched = imdilate(eroded, SE);
    dir_counts(k) = sum(matched(:));
end

dir_hist = dir_counts / (sum(dir_counts) + eps);
feature = dir_hist(:);
end

%% ------------------- 边缘特征 -------------------
function feature = ContourFeature(I)
edges = edge(I, 'Canny');
feature = sum(edges(:)) / numel(I);
end
