文件架构：

haar_main.m 是主文件 ，里面实现了Haar->Huffman和各个方法压缩比的计算

huffman_length.m ：对图像的像素进行直接 Huffman 编码，主要实现原图 → Huffman 编码

diff_encode.m：对图像进行差分编码，主要实现原图 → 差分编码

coeffs_all.mat， dict.mat，len_file.mat，output.bin是中间文件

运行方法

在命令行下输入haar_main

输入待检索图像路径: ./origin.jpg

输入小波变换长度: 512（示例）

# 为什么我的记事本看起来打不出来下划线，但是PowerToys能看到 :-( 