path = input('请输入待检索图像路径: ', 's');
L = input('请输入小波变换长度: ');
if log2(L) ~= round(log2(L))
    error('L 必须是 2 的幂');
end

img = imread(path);
img = imresize(img, [L, L]);  % 保证 L x L

% 文件名（统一）
mid_mat = 'coeffs_all.mat';
out_bin = 'output.bin';
dict_mat = 'dict.mat';
len_mat  = 'len_file.mat';

% 1) Haar 编码并保存中间文件
Haar_encode(img, L, mid_mat);

% 2) Huffman 编码（读取中间文件 -> 写 output.bin, dict.mat, len_file.mat）
Huffman_encode(mid_mat, out_bin, dict_mat, len_mat);

% 3) 读取压缩并解码
coeffs = Huffman_decode(out_bin, dict_mat, len_mat, size(img));
img_rec = Haar_decode(coeffs, size(img), L);

Haar_img = uint8(min(max(round(img_rec),0),255));

figure;
subplot(1,2,1); imshow(img); title('原始图像');
subplot(1,2,2); imshow(Haar_img); title('Huffman 解码后重建图');



% 计算原始比特数
orig_bits = numel(img) * 8;

%% 方法 1: 原图 Huffman
len1 = huffman_length(img(:));
ratio1 = len1 / orig_bits;
%% 方法 2: 差分 + Huffman
diff_img = diff_encode(img);          
len2 = huffman_length(diff_img(:));
ratio2 = len2 / orig_bits;

%% 方法 3: Haar + Huffman
load(len_mat,'len_all');
comp_bits = sum(len_all);       

ratio3 = comp_bits / orig_bits;

fprintf('方法1 原图->Huffman: 压缩比 %.3f\n', ratio1);
fprintf('方法2 差分->Huffman: 压缩比 %.3f\n', ratio2);
fprintf('方法3 Haar->Huffman: 压缩比 %.3f\n', ratio3);


%% -------------------- 函数定义 --------------------

function Haar_encode(img, L, filename)
    H = haar(L);
    [m,n,c] = size(img);

    coeffs_all = cell(1,c);
  
    for k = 1:c
        channel = double(img(:,:,k));
        % 二维 Haar 变换
        C = H * channel * H';
        % 阈值
        sorted = sort(abs(C(:)), 'descend');
        T = sorted(round(0.5 * numel(sorted)));
        C_thr = sign(C) .* max(abs(C) - T, 0);


        coeffs_all{k} = round(C_thr); 
    end

    save(filename, 'coeffs_all', 'm', 'n', 'c', 'L', 'H', '-v7.3');

end

function Huffman_encode(input_mat, output_bin, dict_file, len_file)
    S = load(input_mat, 'coeffs_all','m','n','c');
    coeffs_all = S.coeffs_all;
    c = S.c;
    enco_all = cell(1,c);
    dict_all = cell(1,c);
    len_all = zeros(1,c);

    for k = 1:c
        data = double(coeffs_all{k}(:)); % 确保为列向量和 double
      
        [symbols, ~, ic] = unique(data, 'stable');
        counts = accumarray(ic, 1);
        P = counts / sum(counts);

        dict = huffmandict(symbols, P);    
        enco = huffmanenco(data, dict);

        enco_all{k} = enco;
        dict_all{k} = dict;
        len_all(k) = numel(enco);

    end

    % 将所有通道比特流按序写入二进制文件
    fid = fopen(output_bin, 'w');
    if fid == -1, error('无法创建输出文件 %s', output_bin); end
    for k = 1:c
        fwrite(fid, enco_all{k}, 'ubit1');  % 以位写入
    end
    fclose(fid);
    save(dict_file, 'dict_all', '-v7.3');
    save(len_file, 'len_all', '-v7.3');
 
end

function coeffs = Huffman_decode(input_bin, dict_file, len_file, img_size)
    load(dict_file, 'dict_all');   
    load(len_file, 'len_all');

    fid = fopen(input_bin, 'r');
    if fid == -1, error('无法打开压缩文件 %s', input_bin); end
    enco_read = fread(fid, inf, 'ubit1');
    fclose(fid);

    m = img_size(1); n = img_size(2); c = img_size(3);
    coeffs = cell(1, c);
    % 切分并解码每个通道
    start_idx = 1;
    for k = 1:c
        end_idx = start_idx + len_all(k) - 1;
        enco_k = enco_read(start_idx:end_idx);
        start_idx = end_idx + 1;

        deco = huffmandeco(enco_k, dict_all{k});  % 返回数值向量（原始符号）
        coeffs{k} = reshape(double(deco), m, n);    % 还原 LxL 系数矩阵

      
    end
end

function img_rec = Haar_decode(coeffs,img_size,L)
    H = haar(L);
    m = img_size(1); n = img_size(2); c = img_size(3);
    img_rec = zeros(m, n, c);
    % 按通道解码
    for k = 1:c
        coeff = coeffs{k};   % 获取当前通道的系数
        coeff = reshape(coeff, m, n);  % 将系数恢复成 L x L 矩阵

        % 二维逆变换
        rec = H' * coeff * H;   % 使用 Haar 逆变换
        img_rec(:,:,k) = rec;   % 保存解码后的图像
    end
end

function H = haar(N)
    % 构造正交归一化的 Haar 矩阵 (N = 2^n)
    if log2(N) ~= round(log2(N))
        error('N 必须是 2 的幂');
    end
    H = zeros(N,N);
    H(1,:) = (1/sqrt(N)) * ones(1,N);
    row = 2;
    levels = log2(N);
    for lev = 1:levels
        blocks = 2^(lev-1);
        len = N / blocks;
        half = len/2;
        for b = 1:blocks
            start_idx = (b-1)*len + 1;
            mid_idx = start_idx + half - 1;
            end_idx = start_idx + len - 1;
            v = zeros(1,N);
            v(start_idx:mid_idx) = 1/sqrt(len);
            v(mid_idx+1:end_idx) = -1/sqrt(len);
            H(row, :) = v;
            row = row + 1;
        end
    end
    if row ~= N+1
        warning('Haar matrix row count mismatch, performing orthonormalization.');
        [Q,~] = qr(H);
        H = Q;
    end
end
