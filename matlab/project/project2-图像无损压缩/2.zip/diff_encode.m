function diff_img = diff_encode(img)
    img = double(img);
    diff_img = zeros(size(img));
    diff_img(:,1,:) = img(:,1,:);              % 第一列保持原值
    diff_img(:,2:end,:) = diff(img,1,2);       % 行内差分
    diff_img = int16(diff_img);
end
