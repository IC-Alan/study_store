function len = huffman_length(data)
    data = data(:);
    [symbols, ~, ic] = unique(data,'stable');
    counts = accumarray(ic,1);
    P = counts / sum(counts);
    dict = huffmandict(symbols, P);
    enco = huffmanenco(data, dict);
    len = numel(enco);   % 压缩后比特数
end
